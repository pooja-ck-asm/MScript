import os
import requests
from app.services.vuln import ScanCVE
import json
'''from cachetools import TTLCache
maxsize = 1000
cache = TTLCache(maxsize=maxsize, ttl=3600*168)'''
from dotenv import load_dotenv

load_dotenv()
domain=os.getenv("DOMAIN")
username=os.getenv("USER_NAME")
password=os.getenv("PASSWORD")
api_key=os.getenv("API_KEY")
url=os.getenv("URL")


def download(url: str, dest_folder: str):
    """
    This function download list of range provided from download_all_nvd_json_gz_feeds
    """
    if not os.path.exists(dest_folder):
        os.makedirs(dest_folder)  # create folder if it does not exist
    filename = url.split('/')[-1].replace(" ", "_")  # be careful with file names
    file_path = os.path.join(dest_folder, filename)
    r = requests.get(url, stream=True)
    if r.ok:
        print("saving to", os.path.abspath(file_path))
        with open(file_path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024 * 8):
                if chunk:
                    f.write(chunk)
                    f.flush()
                    os.fsync(f.fileno())
        return True
    else:  # HTTP status code 4XX/5XX
        print("Download failed: status code {}\n{}".format(r.status_code, r.text))
        return False


def download_all_nvd_json_gz_feeds():
    """
    This function has a list of year range and calls for download function
    """
    years = list(range(2002, 2024))
    folder_path = os.path.join(os.path.dirname(os.path.dirname("__file__")), 'resources')
    for year in years:
        url = "https://nvd.nist.gov/feeds/json/cve/1.1/nvdcve-1.1-{0}.json.gz".format(year)
        download(url=url, dest_folder=folder_path) 



def nvd_api():
    """
    This function calls for nvd api with particular host cve_parts and 
    if cve_parts matches with nvd cve_parts it will append to data
    """
    scve=ScanCVE(domain=domain,username=username,password=password)
    res=scve.run()
    data=[]
    
    for cve_data in res:
        if cve_data != '':
            if len(cve_data)<4 or cve_data['application']=='' or cve_data['vendor'] == '' or cve_data['product'] == '' or cve_data['version']== '':
                print("Cve_datas are missing")
                continue
            cve_data_host=cve_data['host']
            st='cpe'+':'+'2.3:'+cve_data['application']+':'+cve_data['vendor']+':'+cve_data['product']+':'+cve_data['version']
            url = os.getenv("URL").format(st)
            response = requests.get(url,headers={'apiKey':os.getenv("API_KEY")})
            if response.status_code != 200:
                print("Error: Request for {0} returned status code {1}".format(st[:-2], response.status_code))
            else:
                result = {'result': response.json(), 'cve_data_host': cve_data_host, 'cpe_name': st}
                data.append(result)
            #cache[st] = result  
    
    return data
