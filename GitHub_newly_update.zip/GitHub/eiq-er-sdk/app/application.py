from flask import Flask
from app.blueprints.vuln import vuln_bp


app = Flask(__name__)

app.register_blueprint(vuln_bp, url_prefix='/vuln')
